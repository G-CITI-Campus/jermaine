document.addEventListener("DOMContentLoaded", init, false);

function init() {
  var canvas =
      document.getElementById("canvas");
      if ("ontouchstart" in document.documentElement) {
        canvas.addEventListener("touchstart", detect, false);
      }
  else {
    canvas.addEventListener("mousedown", detect, false);
  }
}

function detect() {
  if ("ontouchstart" in document.documentElement) {
    alert("Touch screen device detected!");
  }
  else {
    alert("No touch screen device detected.");
  }
}